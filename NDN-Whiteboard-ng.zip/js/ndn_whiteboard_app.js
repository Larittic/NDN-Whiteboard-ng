var ndnWhiteboardApp = angular.module('ndnWhiteboard', ['ui.bootstrap']);
